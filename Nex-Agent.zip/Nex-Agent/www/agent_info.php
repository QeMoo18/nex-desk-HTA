<?php 
	function converted($bytes)
	{

	    $si_prefix = array( 'B', 'KB', 'MB', 'GB', 'TB', 'EB', 'ZB', 'YB' );
	    $base = 1024;
	    $class = min((int)log($bytes , $base) , count($si_prefix) - 1);
	    //echo $bytes . '<br />';
	    return sprintf('%1.2f' , $bytes / pow($base,$class)) . ' ' . $si_prefix[$class];
	}

	function shell($command)
	{
		$output = shell_exec($command);
		$output = explode(PHP_EOL, $output);
		$output = $output[1];
		return $output;
	}

	function get_disks(){
		$disks=`fsutil fsinfo drives`; 
        $disks=str_word_count($disks,1); 
        if($disks[0]!='Drives')return ''; 
        unset($disks[0]); 
        foreach($disks as $key=>$disk)$disks[$key]=$disk.':\\'; 
        return $disks; 
	}
?>



<?php 
	
	$os = PHP_OS;
	$fullname_os = php_uname();
	$current_user = get_current_user();


	// $command = 'wmic computersystem get TotalPhysicalMemory';
	// $ram = shell($command);
	// $ram = str_replace(' ', '', $ram);
	// $ram = converted($ram);

	// $command = 'wmic bios get serialnumber';
	// $serialnumber = shell($command);



	$total_ram = exec('SYSTEMINFO | findstr /C:"Total Physical Memory"');
	$total_ram = str_replace("Total Physical Memory: ","",$total_ram);
	$total_ram = str_replace(",","",$total_ram);
	$total_ram = str_replace(" MB","",$total_ram);
	
	$total_ram = (float)$total_ram;
	$total_ram = 1000000*$total_ram;
	$total_ram = converted($total_ram);
	$free_ram = exec('SYSTEMINFO | findstr /C:"Available Physical Memory"');
	$free_ram = str_replace("Available Physical Memory: ","",$free_ram);
	$free_ram = str_replace(",","",$free_ram);
	$free_ram = str_replace(" MB","",$free_ram);
	
	$free_ram = (float)$free_ram;
	$free_ram = 1000000*$free_ram;
	$free_ram = converted($free_ram);


	$ram = "Total RAM : ".$total_ram." | Free RAM : ".$free_ram;



	
	$serialnumber = exec('SYSTEMINFO | findstr /C:"Product ID"');
	$serialnumber = str_replace("Product ID: ","",$serialnumber);


	//$serialnumber = exec('dir/p/w | findstr /C:"Serial Number"');

	$model = exec('SYSTEMINFO | findstr /C:"System Model"');
	$model = str_replace("System Model: ","",$model);

	//$cpu_model = exec('SYSTEMINFO | findstr /C:"Processor"');

	$date = exec('SYSTEMINFO | findstr /C:"Original Install Date"');
	$date = str_replace("Original Install Date: ","",$date);


	//echo $date; exit();
	// var_dump($total_ram); exit();

	// $command = 'WMIC CSPRODUCT GET NAME';
	// $model = shell($command);

	// $command = 'WMIC CSPRODUCT GET DESCRIPTION';
	// $desc = shell($command);

	// $command = 'wmic CPU get NAME';
	// $cpu_model = shell($command);

	// $command = 'wmic CPU get DESCRIPTION';
	// $cpu_desc = shell($command);


	// $command = 'wmic nicconfig where "IPEnabled  = True" get ipaddress';
	// $ip_enabled = shell($command);

	$free_disk = converted(disk_free_space(".")); 
	$total_disc = converted(disk_total_space("."));

	$mac_address = exec('getmac');
	$mac_address = str_replace('Media disconnected', '', $mac_address);

	$ip = getHostByName(getHostName());

	$name_pc = getenv('COMPUTERNAME');


	//var_dump($ip);
	//exit();


?>


<?php 


	$arr = array(	'os'=>$os,
					'fullname_os'=>$fullname_os,
					'name_pc'=>$name_pc,
					'free_disc'=>$free_disk,
					'total_disc'=>$total_disc,
					'ram'=>$ram,
					'serialnumber'=>$serialnumber,
					'model'=>$model,
					//'description'=>$desc,
					'user'=>$current_user,
					//'cpu_model'=>$cpu_model,
					//'cpu_desc'=>$cpu_desc,
					//'ip_enabled'=>$ip_enabled,
					'ip'=>$ip,
					'current_user'=>$current_user,
					//'partition'=>get_disks(),
					'mac_address'=>$mac_address

				);
	echo json_encode($arr);

?>

