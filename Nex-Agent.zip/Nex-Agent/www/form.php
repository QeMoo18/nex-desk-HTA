<?php //header('Access-Control-Allow-Origin: *');?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="asset/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>System Message - Agent </title>
  </head>


  <body style='background-color:rgb(243, 242, 242);'>

  	<br><br>
  	<div class="row">
  		<div class="col-xs-2 col-sm-2 col-md-2"> </div>
  		<div class="col-xs-8 col-sm-8 col-md-8" id="data_put"> 
  			
        <b><p> Sorry for interrupt..</b>  Our agent cannot detect your location. <br><br></p>

       
        <label>Please select your location first</label>
        <select class="form-control" id="location">
          <option value="">-- Select Location --</option>

<option value="admin-cme">admin-cme</option><option value="admin-unit-gaji">admin-unit-gaji</option><option value="admin-unit-kejuruteraan">admin-unit-kejuruteraan</option><option value="admin-unit-sumber-manusia">admin-unit-sumber-manusia</option><option value="bilik-kpf.farmasi">bilik-kpf.farmasi</option><option value="bilik-pegawai-farmasi-u48-level-">bilik-pegawai-farmasi-u48-level-</option><option value="bilik-pemandu-level-1">bilik-pemandu-level-1</option><option value="bitnb">bitnb</option><option value="bitpc">bitpc</option><option value="crc-office">crc-office</option><option value="cssd-level-2">cssd-level-2</option><option value="dialysis-capd">dialysis-capd</option><option value="dietitik-dan-sajian">dietitik-dan-sajian</option><option value="drug-information-level-2.farmasi">drug-information-level-2.farmasi</option><option value="farmasi">farmasi</option><option value="general-medical-clinic">general-medical-clinic</option><option value="got">got</option><option value="hand-and-micro-clinic">hand-and-micro-clinic</option><option value="hepatobiliary-clinic">hepatobiliary-clinic</option><option value="hospital.selayang">hospital.selayang</option><option value="infection-control-unit">infection-control-unit</option><option value="it-department">it-department</option><option value="l2-day-care-endo">l2-day-care-endo</option><option value="l2-daycare-ot">l2-daycare-ot</option><option value="l2-diagnostic-imaging">l2-diagnostic-imaging</option><option value="l2-emergency-department">l2-emergency-department</option><option value="l2-in-patient.farmasi">l2-in-patient.farmasi</option><option value="l3-admin-asrama-jururawat">l3-admin-asrama-jururawat</option><option value="l3-admin-health-education-penyelia-ma">l3-admin-health-education-penyelia-ma</option><option value="l3-admin-jabatan-hal-ehwal-islam">l3-admin-jabatan-hal-ehwal-islam</option><option value="l3-admin-jabatan-kerja-sosial-perubatan-">l3-admin-jabatan-kerja-sosial-perubatan-</option><option value="l3-admin-library">l3-admin-library</option><option value="l3-admin-matron-office">l3-admin-matron-office</option><option value="l3-admin-operator">l3-admin-operator</option><option value="l3-admin-pembantu-keselamatan">l3-admin-pembantu-keselamatan</option><option value="l3-admin-perhubungan-awam">l3-admin-perhubungan-awam</option><option value="l3-admin-perolehan">l3-admin-perolehan</option><option value="l3-admin-unit-hasil">l3-admin-unit-hasil</option><option value="l3-admin-unit-kesihatan-awam">l3-admin-unit-kesihatan-awam</option><option value="l3-admin-unit-kewangan">l3-admin-unit-kewangan</option><option value="l3-admin-unit-kualiti">l3-admin-unit-kualiti</option><option value="l3-admin-unit-pengurusan-aset">l3-admin-unit-pengurusan-aset</option><option value="l3-admin-unit-pentadbiran">l3-admin-unit-pentadbiran</option><option value="l3-anaest-clinic">l3-anaest-clinic</option><option value="l3-chest-staff-clinic">l3-chest-staff-clinic</option><option value="l3-eye-clinic">l3-eye-clinic</option><option value="l3-itd">l3-itd</option><option value="l3-itd-bilik-latihan">l3-itd-bilik-latihan</option><option value="l3-itd-bilik-seminar">l3-itd-bilik-seminar</option><option value="l3-obsteric-gynaecology-clinic">l3-obsteric-gynaecology-clinic</option><option value="l3-orl-clinic">l3-orl-clinic</option><option value="l3-out-patient.farmasi">l3-out-patient.farmasi</option><option value="l3-paediatric-clinic">l3-paediatric-clinic</option><option value="l3-rheumatology-clinic">l3-rheumatology-clinic</option><option value="l3-specialist-clinic">l3-specialist-clinic</option><option value="l4-counter-specialist-clinic">l4-counter-specialist-clinic</option><option value="l4-dermatology-psychiatry-clinic">l4-dermatology-psychiatry-clinic</option><option value="l4-diagnostic-imaging-">l4-diagnostic-imaging-</option><option value="l4-oral-surgery-clinic">l4-oral-surgery-clinic</option><option value="l4-out-patient.farmasi">l4-out-patient.farmasi</option><option value="l4-patologi">l4-patologi</option><option value="l4-pejabat-pakar">l4-pejabat-pakar</option><option value="l4-surgical-orthopedic-clinic">l4-surgical-orthopedic-clinic</option><option value="l4-urology-nefrology-clinic">l4-urology-nefrology-clinic</option><option value="l5-burn-unit">l5-burn-unit</option><option value="l5-ccu">l5-ccu</option><option value="l5-hdw">l5-hdw</option><option value="l5-icu">l5-icu</option><option value="laboor-room">laboor-room</option><option value="main-office.farmasi">main-office.farmasi</option><option value="manufacturing-level-2.farmasi">manufacturing-level-2.farmasi</option><option value="mortuary-forensic-level-2">mortuary-forensic-level-2</option><option value="mot">mot</option><option value="nicu">nicu</option><option value="pac">pac</option><option value="pandu-lalu.farmasi">pandu-lalu.farmasi</option><option value="pusat-laktasi">pusat-laktasi</option><option value="rehab">rehab</option><option value="rekod-perubatan">rekod-perubatan</option><option value="satelite-klinikal-level-6.farmasi">satelite-klinikal-level-6.farmasi</option><option value="satelite-level-5.farmasi">satelite-level-5.farmasi</option><option value="satelite-level-7.farmasi">satelite-level-7.farmasi</option><option value="satelite-level-9.farmasi">satelite-level-9.farmasi</option><option value="sister-on-call-room">sister-on-call-room</option><option value="stor-perubatan-level-2.farmasi">stor-perubatan-level-2.farmasi</option><option value="stor-pusat-level-2">stor-pusat-level-2</option><option value="unit-aseptik-level-2.farmasi">unit-aseptik-level-2.farmasi</option><option value="unit-mekar-level-2">unit-mekar-level-2</option><option value="wad-4c">wad-4c</option><option value="ward-10a">ward-10a</option><option value="ward-10b">ward-10b</option><option value="ward-10c">ward-10c</option><option value="ward-10d">ward-10d</option><option value="ward-11b">ward-11b</option><option value="ward-11c">ward-11c</option><option value="ward-2c">ward-2c</option><option value="ward-4a">ward-4a</option><option value="ward-4b">ward-4b</option><option value="ward-4d">ward-4d</option><option value="ward-5a">ward-5a</option><option value="ward-5b">ward-5b</option><option value="ward-5c">ward-5c</option><option value="ward-5d">ward-5d</option><option value="ward-6a">ward-6a</option><option value="ward-6b">ward-6b</option><option value="ward-6c">ward-6c</option><option value="ward-6d">ward-6d</option><option value="ward-7a">ward-7a</option><option value="ward-7b">ward-7b</option><option value="ward-7c">ward-7c</option><option value="ward-7d">ward-7d</option><option value="ward-8a">ward-8a</option><option value="ward-8b">ward-8b</option><option value="ward-8c">ward-8c</option><option value="ward-8d">ward-8d</option><option value="ward-9a">ward-9a</option><option value="ward-9b">ward-9b</option><option value="ward-9c">ward-9c</option><option value="ward-9d">ward-9d</option>

        </select>


        <br>
        <button class="btn btn-primary btn-block" onclick="submit_location();">Submit</button>
     

			  </div>
			</div>
  		</div>
  		<div class="col-xs-2 col-sm-2 col-md-2"> </div>
  	</div>

  <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>

<script src="js/jquery.min.js"></script>



<script type="text/javascript">
	$(document).ready(function (){
		submit(1);
	});


	function submit(Status)
  {
    //input daripada form - id
    //var Status = '1';

    var data = 
                    {   
                      'Status':Status
                    }

                    
            $.ajax({
                    url: 'http://127.0.0.1:8000/get_name_pc.php',
                    type: 'POST',
                    dataType: 'json',
                    data: data,
                    beforeSend: function() {

                    },
                    cache: false,
                    success: function(response){
                      //alert(response.cpu_model);
                      //notice();
                      //$("#cpu_desc").val(response.cpu_desc);
                      //$("#cpu_model").val(response.cpu_model);
                      $("#name_pc").val(response.name_pc);



                      

                    }
            });
    
  }


  function submit_location()
  {
    var location = $("#location").val();

    if(location){
      var name_pc = $("#name_pc").val();

      var data = 
                    {   
                      'name_pc':name_pc,
                      'location':location
                    }

                    
            $.ajax({
                    url: 'http://10.1.20.95/nex-hospital/admin/update_location_agent',
                    type: 'POST',
                    dataType: 'html',
                    data: data,
                    beforeSend: function() {

                    },
                    cache: false,
                    success: function(response){
                        $("#data_put").html('<b><p> Thank you for giving us feedback. We really appreciate your response.. Enjoy our services..</p></b>');


                        setTimeout(function() { window.close(); }, 3000);

                    } 
            });

    } else {

    }

  }

</script>

<!-- HIDDEN FIELD -->
<input type="hidden" id="name_pc">