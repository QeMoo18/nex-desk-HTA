<?php 
	
	//header('Access-Control-Allow-Origin: *');
	
	// exec("background.vbs");

	// echo '1';
?>