<?php //header('Access-Control-Allow-Origin: *');?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="asset/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>Hello, world!</title>
  </head>
  <body style='background-color:rgb(243, 242, 242);'>

  	<nav class="navbar navbar-expand-lg navbar-light bg-light">
	  <a class="navbar-brand" href="#"></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav mr-auto">
	      <li class="nav-item active" onclick="home();">
	        <a class="nav-link" >Home <span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item" onclick="contact();">
	        <a class="nav-link" >Contact Us</a>
	      </li>
	    </ul>
	  </div>
	</nav>

	<br>
	<div class="container">

	  <div id="body_contain"> 
		  <div class="row">
		    <div class="col">
		    	<center>
		    		<a href="" id="sleep">
		    			<img src="img/img.png" class="img-fluid" alt="Responsive image" style="height:100px; width:130px;">
		    		</a>


		    		<a href="" id="loading" style="display: none">
		    			<img src="img/loader.gif" class="img-fluid" alt="Responsive image">
		    		</a>


		    		<a href="" id="wakeup" style="display: none">
		    			<img src="img/wakeup.png" class="img-fluid" alt="Responsive image" style="height:100px; width:130px;">
		    		</a>

		    		

		    	</center>
		    </div>
		  </div>
		  <br><br>
		  <div class="row">
		    <div class="col">
		    	<center>
		    		<button class="btn btn-success" id="connect" onclick="connect();">CONNECT</button>
		    		<button class="btn btn-danger" id="disconnect" onclick="disconnect();" style="display: none;">DISCONNECT</button>
		    	</center>
		    </div>
		  </div>
	  </div>


	  <div id="body_contain2" style="display: none;"> 
	  	  <div class="row">
		    <div class="col">
		    	<div class="form-group">
				    <label for="exampleInputEmail1">Company</label>
				    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" disabled="disabled" value="Nexquadrant Sdn Bhd">
				</div>
		    </div>
		  </div>
		  <div class="row">
		    <div class="col">
		    	<div class="form-group">
				    <label for="exampleInputEmail1">Email</label>
				    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" disabled="disabled" value="info@nexquadrant.com">
				</div>
		    </div>
		  </div>
		  <div class="row">

		    <div class="col">
		    	<div class="form-group">
				    <label for="exampleInputEmail1">Phone</label>
				    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" disabled="disabled" value="+603-83-200-100" disabled="disabled">
				</div>
		    </div>
		  </div>

		  <div class="row">

		    <div class="col">
		    	<div class="form-group">
				    <label for="exampleInputEmail1">Address</label>
				     <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" value="">480009-2-29, Jalan Perdana, CBD Perdana 2, Cyber 12, 63000 Cyberjaya, Selangor, Malaysia</textarea>
				</div>
		    </div>
		  </div>
	  </div>


	  <br>
	  <div class="row">
	    <div class="col">
	    	<center>
	    			<font size="1px"> Like Nex-Hospital On Facebook <i class="fa fa-facebook-official"></i></font>
	    			<br> 
	    			<font size="1px">
	    			<strong>Copyright &copy; 2018 <a href="http://bit.com.my">Nexquadrant Sdn Bhd</a>.</strong> 
	    			</font>
	    	</center>
	    </div>
	  </div>
	</div>




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>

<script src="js/jquery.min.js"></script>
<script type="text/javascript">
	function connect()
	{
		
		$("#connect").hide();
		$("#disconnect").show();

		$("#sleep").hide();
		$("#wakeup").show();
		//$("#loading").show();
		//setInterval(function(){ hide_loading_connect(); }, 3000);
		submit(1);
	}

	function disconnect()
	{
		$("#connect").show();
		$("#disconnect").hide();

		$("#sleep").show();
		$("#wakeup").hide();
		//$("#loading").show();
		//setInterval(function(){ hide_loading_disconnect(); }, 3000);
		submit(0);


	}

	function hide_loading_connect()
	{

		$("#wakeup").show();
		$("#sleep").hide();
		$("#loading").hide();
	}

	function hide_loading_disconnect()
	{

		$("#wakeup").hide();
		$("#sleep").show();
		$("#loading").hide();
	}

	function home()
	{
		//alert('a');
		$("#body_contain").show();
		$("#body_contain2").hide();
	}

	function contact()
	{
		$("#body_contain").hide();
		$("#body_contain2").show();
	}

	

	function submit(Status)
	{
		//input daripada form - id
		//var Status = '1';

		var data = 
		                {   
		                	'Status':Status
		                }

                    
            $.ajax({
                    url: 'http://127.0.0.1:8000/agent_info.php',
                    type: 'POST',
                    dataType: 'json',
                    data: data,
                    beforeSend: function() {

                    },
                    cache: false,
                    success: function(response){
                    	//alert(response.cpu_model);
                    	//notice();
                    	$("#cpu_desc").val(response.cpu_desc);
                    	$("#cpu_model").val(response.cpu_model);
                    	$("#name_pc").val(response.name_pc);
                    	$("#description").val(response.description);
                    	$("#free_disc").val(response.free_disc);
                    	$("#fullname_os").val(response.fullname_os);
                    	$("#ip").val(response.ip);
                    	//$("#ip_enabled").val(response.ip_enabled);
                    	$("#mac_address").val(response.mac_address);
                    	$("#model").val(response.model);
                    	$("#os").val(response.os);
                    	$("#partition").val(response.partition);
                    	$("#ram").val(response.ram);
                    	$("#serialnumber").val(response.serialnumber);
                    	$("#total_disc").val(response.total_disc);
                    	$("#user").val(response.user);

                    	check_location_agent(response.name_pc);
                    	notice();
                    	//setInterval(push_agent(Status), 30000);

                    	if(Status=='1'){

                    		window.setInterval(function(){
	                    		notice()
							  /// call your function here
							}, 30000);

							window.setInterval(function(){
	                    		push_agent(Status)
							  /// call your function here
							}, 30000);

                    	} else {
                    		push_agent(Status);
                    		clearInterval();
                    	}

                    	

                    }
            });
		
	}




	function notice()
	{
		var COMP_Name = $("#name_pc").val();
		var data = 
		                {   'COMP_Name':COMP_Name
		                }

                    
            $.ajax({
                    url: 'http://10.1.20.95/nex-hospital/Admin/net_send_agent_notice',
                    type: 'POST',
                    dataType: 'html',
                    data: data,
                    beforeSend: function() {

                    },
                    success: function(response){
                    	

                    	if(response){
                    		

						    window.open('http://127.0.0.1:8000/notice_info.php', '_blank'); 

						    readNotice(COMP_Name);

						    

                    	}
                    	

                    }
            });
	}


	function readNotice(COMP_Name)
	{
		//var COMP_Name = $("#user").val();
		var data = 
		                {   'COMP_Name':COMP_Name
		                }

                    
            $.ajax({
                    url: 'http://10.1.20.95/nex-hospital/Admin/net_send_agent_read_notice',
                    type: 'POST',
                    dataType: 'html',
                    data: data,
                    beforeSend: function() {

                    },
                    success: function(response){
                    	


                    }
            });
	}


	function push_agent(Status)
	{
		$("#cpu_desc").val();
    	$("#cpu_model").val();
    	$("#name_pc").val();
    	$("#description").val();
    	var free = $("#free_disc").val();
    	$("#free_disk_c").val();
    	$("#free_disk_d").val();
    	$("#fullname_os").val();
    	$("#ip").val();
    	$("#ip_enabled").val();
    	$("#mac_address").val();
    	$("#model").val();
    	$("#os").val();
    	$("#partition").val();
    	$("#ram").val();
    	$("#serialnumber").val();
    	var total = $("#total_disc").val();
    	$("#total_disk_c").val();
    	$("#total_disk_d").val();
    	$("#user").val();

    	$("#name_pc").val();

    	var COMP_Name = $("#name_pc").val();
		var COMP_Deployment_State = 'Production';
		var COMP_Incident_State = 'Operational';
		//var COMP_vendor = $("#COMP_vendor").val();
		var COMP_model = $("#model").val();
		var COMP_description = $("#description").val();
		var COMP_type = 'Desktop';
		var COMP_owner = $("#user").val();
		var COMP_SerialNo = $("#serialnumber").val();
		var COMP_OS = $("#os").val();
		var COMP_CPU = $("#cpu_model").val();
		var COMP_RAM = $("#ram").val();

		var COMP_hardisk = 'Total '+total+' | Free '+free;

		// alert(COMP_hardisk);

		// var COMP_hardisk = $("#partition").val();
		//var COMP_capacity = $("#COMP_capacity").val();
		//var COMP_FQDN = $("#COMP_FQDN").val();
		//var COMP_NA = $("#COMP_NA").val();
		//var COMP_GA = $("#COMP_GA").val();
		//var COMP_OE = $("#COMP_OE").val();
		//var COMP_WAD = $("#COMP_WAD").val();
		//var COMP_InstallDate = $("#COMP_InstallDate").val();
		//var COMP_Notes = $("#COMP_Notes").val();
		//var COMP_Location = $("#COMP_Location").val();

		//var COMP_Location = 'bilik-kpf.farmasi';
		var COMP_validity = 'Valid';
		
		var COMP_ip = $("#ip").val();


		var data = 
		                {   'COMP_Name':COMP_Name,
		                	'COMP_Deployment_State':COMP_Deployment_State,
		                	'COMP_Incident_State':COMP_Incident_State,
		                	// 'COMP_vendor':COMP_vendor,
		                	'COMP_model':COMP_model,
		                	'COMP_description':COMP_description,
		                	'COMP_type':COMP_type,
		                	'COMP_owner':COMP_owner,
		                	'COMP_SerialNo':COMP_SerialNo,
		                	'COMP_OS':COMP_OS,
		                	'COMP_CPU':COMP_CPU,
		                	'COMP_RAM':COMP_RAM,
		                	'COMP_hardisk':COMP_hardisk,
		                	// 'COMP_capacity':COMP_capacity,
		                	// 'COMP_FQDN':COMP_FQDN,
		                	// 'COMP_NA':COMP_NA,
		                	// 'COMP_GA':COMP_GA,
		                	// 'COMP_OE':COMP_OE,
		                	// 'COMP_WAD':COMP_WAD,
		                	// 'COMP_InstallDate':COMP_InstallDate,
		                	// 'COMP_Notes':COMP_Notes,
		                	//'COMP_Location':COMP_Location,
		                	'COMP_validity':COMP_validity,
		                	'COMP_ip':COMP_ip,
		                	'Status':Status
		                }

                    
            $.ajax({
                    url: 'http://10.1.20.95/nex-hospital/Admin/computer_agent_add',
                    type: 'POST',
                    dataType: 'html',
                    data: data,
                    beforeSend: function() {

                    },
                    success: function(response){
                    	//alert("Data Saved !");
                    	//location.reload();
                    	
                    }
            });
	}

	function check_location_agent(name_pc){

		var check_loc = $("#check_loc").val();

		if(check_loc){

		} else {
			var data = 
		                {   
		                	'name_pc':name_pc
		                }

                    
            $.ajax({
                    url: 'http://10.1.20.95/nex-hospital/Admin/check_location_agent',
                    type: 'POST',
                    dataType: 'html',
                    data: data,
                    beforeSend: function() {

                    },
                    cache: false,
                    success: function(response){
                    	$("#check_loc").val('1');
                    	if(response>0){
						    window.open('http://127.0.0.1:8000/form.php', '_blank'); 
                    	} else {
                    		
                    	}
                    }
                });
		}

		

	}
	
	$(document).ready(function (){
		submit(1);
	});

</script>




<!-- HIDDEN FIELD -->
<input type="hidden" id="cpu_desc">
<input type="hidden" id="cpu_model">
<input type="hidden" id="name_pc">
<input type="hidden" id="description">
<input type="hidden" id="free_disc">
<input type="hidden" id="free_disk_c">
<input type="hidden" id="free_disk_d">
<input type="hidden" id="fullname_os">
<input type="hidden" id="ip">
<input type="hidden" id="ip_enabled">
<input type="hidden" id="mac_address">
<input type="hidden" id="model">
<input type="hidden" id="os">
<input type="hidden" id="partition">
<input type="hidden" id="ram">
<input type="hidden" id="serialnumber">
<input type="hidden" id="total_disc">
<input type="hidden" id="total_disk_c">
<input type="hidden" id="total_disk_d">
<input type="hidden" id="user">

<input type="hidden" id="check_loc">