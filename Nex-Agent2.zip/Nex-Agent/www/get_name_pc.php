<?php 
	
	$name_pc = getenv('COMPUTERNAME');
	$arr = array(	
					'name_pc'=>$name_pc

				);
	echo json_encode($arr);

?>